interface FooterProps {
  fgItems: number;
  customers: number;
  dealers: number;
  soLines: number;
}

export default function Footer({ fgItems, customers, dealers, soLines }: FooterProps) {
  return (
    <footer className="flex items-center justify-between border-t bg-white px-6 py-2.5 text-xs text-slate-500">
      <div className="flex items-center gap-4">
        <span>FG Items: <b className="text-slate-800">{fgItems}</b></span>
        <span>Customers: <b className="text-blue-600">{customers}</b></span>
        <span>Dealers: <b className="text-slate-800">{dealers}</b></span>
        <span>SO Lines: <b className="text-slate-800">{soLines}</b></span>
      </div>
      <div className="text-slate-400">JANATICS · July 2026 · Thu, 16 Jul 2026</div>
    </footer>
  );
}
