import { Item, ItemDetailData } from "./types";

export const items: Item[] = [
  { code: "PV-5001", description: "Solenoid Valve 5/2 Way 1/4\"", type: "AMS1", ocq: 500, ordQty: 1222, autoSp: 500, appvdSp: null, pendSp: 722, trend: "up", trendPct: "+3%", constrained: true, constraintLabel: "Solenoid Coil 24VDC" },
  { code: "PV-5002", description: "Solenoid Valve 5/2 Way 3/8\"", type: "AMS1", ocq: 300, ordQty: 990, autoSp: 300, appvdSp: null, pendSp: 690, trend: "flat", trendPct: "flat", constrained: false },
  { code: "PC-3001", description: "Pneumatic Cylinder Ø32×100 DS", type: "AMS1", ocq: 200, ordQty: 530, autoSp: 200, appvdSp: null, pendSp: 330, trend: "flat", trendPct: "flat", constrained: true, constraintLabel: "Piston Seal Kit" },
  { code: "PC-3002", description: "Pneumatic Cylinder Ø50×150 DS", type: "AMS2", ocq: 120, ordQty: 428, autoSp: null, appvdSp: null, pendSp: 428, trend: "flat", trendPct: "flat", constrained: false },
  { code: "AF-2001", description: "Air Filter 1/4\" 5µm", type: "AMS1", ocq: 400, ordQty: 1482, autoSp: 400, appvdSp: null, pendSp: 1082, trend: "up", trendPct: "+4%", constrained: false },
  { code: "AF-2002", description: "Air Filter 3/8\" 40µm", type: "AMS2", ocq: 210, ordQty: 565, autoSp: null, appvdSp: null, pendSp: 565, trend: "up", trendPct: "+3%", constrained: true, constraintLabel: "Filter Element" },
  { code: "FR-4001", description: "Filter Regulator Combo 1/4\"", type: "AMS1", ocq: 250, ordQty: 882, autoSp: 250, appvdSp: null, pendSp: 632, trend: "flat", trendPct: "flat", constrained: true, constraintLabel: "Gauge Assembly" },
  { code: "MA-6001", description: "Manifold Block 4-Station", type: "AMS2", ocq: 80, ordQty: 203, autoSp: null, appvdSp: null, pendSp: 203, trend: "flat", trendPct: "flat", constrained: false },
  { code: "AC-7001", description: "Actuator Compact Ø20×25", type: "AMS1", ocq: 350, ordQty: 1162, autoSp: 350, appvdSp: null, pendSp: 812, trend: "down", trendPct: "-9%", constrained: true, constraintLabel: "Rod Bearing" },
  { code: "FT-8001", description: "Push-In Fitting Ø6 Straight", type: "AMS1", ocq: 2000, ordQty: 3050, autoSp: 2000, appvdSp: null, pendSp: 1050, trend: "up", trendPct: "+4%", constrained: false },
  { code: "LU-9001", description: "Mist Lubricator 1/4\"", type: "AMS2", ocq: 160, ordQty: 269, autoSp: null, appvdSp: null, pendSp: 269, trend: "up", trendPct: "+3%", constrained: true, constraintLabel: "Oil Reservoir" },
  { code: "VB-1001", description: "Valve Bank Assembly 8-Way", type: "AMS2", ocq: 55, ordQty: 163, autoSp: null, appvdSp: null, pendSp: 163, trend: "flat", trendPct: "flat", constrained: false },
  { code: "MA-6002", description: "Manifold Block 6-Station", type: "AMS2", ocq: 60, ordQty: 42, autoSp: null, appvdSp: null, pendSp: 42, trend: "up", trendPct: "+4%", constrained: false },
  { code: "PC-3004", description: "Pneumatic Cylinder Ø63×200 DS", type: "AMS2", ocq: 90, ordQty: 68, autoSp: null, appvdSp: null, pendSp: 68, trend: "up", trendPct: "+3%", constrained: false },
  { code: "SV-5005", description: "Solenoid Valve 5/2 Way 1/2\" NO", type: "AMS2", ocq: 130, ordQty: 95, autoSp: null, appvdSp: null, pendSp: 95, trend: "flat", trendPct: "flat", constrained: false },
];

export const itemDetails: Record<string, ItemDetailData> = {
  "PV-5001": {
    ocq: 500,
    totalOrders: 1222,
    abovePlan: 722,
    dispatched: 820,
    autoSp: 500,
    appvdSp: 0,
    pendSpQty: 722,
    orders: [
      { cat: "D1", customer: "Pneumatic Solutions Pvt Ltd", oaDate: "11 Jul", oaNo: "SO-25-0182", oaQty: 212, disp: 0, pendOrd: 212, autoSp: null, submitted: null, appvdSp: null, pendSp: 212 },
      { cat: "C2", customer: "Tata Motors Ltd", oaDate: "05 Jul", oaNo: "SO-25-0213", oaQty: 240, disp: 210, pendOrd: 30, autoSp: 100, submitted: null, appvdSp: null, pendSp: 140 },
      { cat: "C2", customer: "Mahindra & Mahindra", oaDate: "06 Jul", oaNo: "SO-25-0228", oaQty: 195, disp: 160, pendOrd: 35, autoSp: null, submitted: null, appvdSp: null, pendSp: 195 },
      { cat: "D2", customer: "Fluid Power India", oaDate: "13 Jul", oaNo: "SO-25-0294", oaQty: 175, disp: 130, pendOrd: 45, autoSp: null, submitted: null, appvdSp: null, pendSp: 175 },
    ],
  },
};
