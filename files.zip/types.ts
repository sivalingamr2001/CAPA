export type AmsType = "AMS1" | "AMS2";
export type Trend = "up" | "down" | "flat";
export type CatCode = "D1" | "D2" | "C2";

export interface Item {
  code: string;
  description: string;
  type: AmsType;
  ocq: number;
  ordQty: number;
  autoSp: number | null;
  appvdSp: number | null;
  pendSp: number;
  trend: Trend;
  trendPct: string;
  constrained: boolean;
  constraintLabel?: string;
}

export interface SalesOrderLine {
  cat: CatCode;
  customer: string;
  oaDate: string;
  oaNo: string;
  oaQty: number;
  disp: number;
  pendOrd: number;
  autoSp: number | null;
  submitted: number | null;
  appvdSp: number | null;
  pendSp: number;
}

export interface ItemDetailData {
  ocq: number;
  totalOrders: number;
  abovePlan: number;
  dispatched: number;
  autoSp: number;
  appvdSp: number;
  pendSpQty: number;
  orders: SalesOrderLine[];
}
