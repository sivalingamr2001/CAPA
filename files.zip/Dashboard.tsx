import { useState } from "react";
import Header from "./Header";
import SummaryCards from "./SummaryCards";
import ItemsTable from "./ItemsTable";
import ItemDetail from "./ItemDetail";
import Footer from "./Footer";
import { items, itemDetails } from "../mock-data";

const constraintCodes = ["PV-5001", "PC-3001", "AF-2002", "FR-4001", "AC-7001", "LU-9001"];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<"items" | "customers">("items");
  const [selectedCode, setSelectedCode] = useState<string | null>(null);

  const handleSelectItem = (code: string) => setSelectedCode(code);
  const handleBack = () => setSelectedCode(null);
  const handleRefresh = () => setSelectedCode(null);

  const selectedItem = selectedCode ? items.find((i) => i.code === selectedCode) : undefined;
  const selectedDetail = selectedCode ? itemDetails[selectedCode] : undefined;

  return (
    <div className="min-h-screen bg-slate-50">
      <Header activeTab={activeTab} onTabChange={setActiveTab} onRefresh={handleRefresh} />

      {/* Top summary cards persist across both the items list and item detail views */}
      <SummaryCards constraintCodes={constraintCodes} onConstraintClick={handleSelectItem} />

      {activeTab === "items" && !selectedItem && (
        <ItemsTable items={items} onSelectItem={handleSelectItem} />
      )}

      {activeTab === "items" && selectedItem && selectedDetail && (
        <ItemDetail item={selectedItem} detail={selectedDetail} onBack={handleBack} />
      )}

      {activeTab === "customers" && (
        <div className="mx-6 mb-6 rounded-xl border bg-white p-10 text-center text-slate-400">
          Customers &amp; Dealers view
        </div>
      )}

      <Footer fgItems={22} customers={7} dealers={6} soLines={88} />
    </div>
  );
}
