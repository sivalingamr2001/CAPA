import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Item, AmsType } from "../types";

interface ItemsTableProps {
  items: Item[];
  onSelectItem: (code: string) => void;
}

type TypeFilter = "All AMS" | AmsType;
type ConstraintFilter = "All" | "Constrained" | "Unconstrained";

function Trend({ trend, pct }: { trend: Item["trend"]; pct: string }) {
  const color = trend === "up" ? "text-emerald-500" : trend === "down" ? "text-red-500" : "text-slate-400";
  const arrow = trend === "up" ? "↗" : trend === "down" ? "↘" : "—";
  return <span className={`text-xs font-medium ${color}`}>{arrow} {pct}</span>;
}

export default function ItemsTable({ items, onSelectItem }: ItemsTableProps) {
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<TypeFilter>("All AMS");
  const [constraintFilter, setConstraintFilter] = useState<ConstraintFilter>("All");
  const [spPendingOnly, setSpPendingOnly] = useState(true);

  const filtered = useMemo(() => {
    return items.filter((it) => {
      const q = query.toLowerCase();
      const matchesQuery = !q || it.code.toLowerCase().includes(q) || it.description.toLowerCase().includes(q);
      const matchesType = typeFilter === "All AMS" || it.type === typeFilter;
      const matchesConstraint =
        constraintFilter === "All" ||
        (constraintFilter === "Constrained" && it.constrained) ||
        (constraintFilter === "Unconstrained" && !it.constrained);
      const matchesSp = !spPendingOnly || it.pendSp > 0;
      return matchesQuery && matchesType && matchesConstraint && matchesSp;
    });
  }, [items, query, typeFilter, constraintFilter, spPendingOnly]);

  return (
    <div className="mx-6 mb-6 rounded-xl border bg-white">
      <div className="flex flex-wrap items-center gap-3 border-b p-4">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search code or description"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-8"
          />
        </div>

        <span className="ml-2 text-xs font-semibold text-slate-400">TYPE</span>
        {(["All AMS", "AMS1", "AMS2"] as TypeFilter[]).map((t) => (
          <Button key={t} size="sm" variant={typeFilter === t ? "default" : "outline"} onClick={() => setTypeFilter(t)}
            className={typeFilter === t ? "bg-blue-600 hover:bg-blue-700" : ""}>
            {t}
          </Button>
        ))}

        <span className="ml-2 text-xs font-semibold text-slate-400">CONSTRAINT</span>
        {(["All", "Constrained", "Unconstrained"] as ConstraintFilter[]).map((c) => (
          <Button key={c} size="sm" variant={constraintFilter === c ? "default" : "outline"} onClick={() => setConstraintFilter(c)}
            className={constraintFilter === c ? "bg-blue-600 hover:bg-blue-700" : ""}>
            {c}
          </Button>
        ))}

        <label className="ml-2 flex items-center gap-2 text-sm">
          <Checkbox checked={spPendingOnly} onCheckedChange={(v) => setSpPendingOnly(Boolean(v))} />
          SP Pending only
        </label>

        <span className="ml-auto text-sm text-slate-400">{filtered.length}/{items.length} items</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-left text-xs font-semibold text-slate-400">
              <th className="px-4 py-3">ITEM CODE</th>
              <th className="px-4 py-3">DESCRIPTION</th>
              <th className="px-4 py-3">TYPE</th>
              <th className="px-4 py-3 text-right">OCQ / PLAN QTY</th>
              <th className="px-4 py-3 text-right">ORD QTY</th>
              <th className="px-4 py-3 text-right">ABOVE OCQ</th>
              <th className="px-4 py-3 text-right">AUTO SP</th>
              <th className="px-4 py-3 text-right">APPVD SP</th>
              <th className="px-4 py-3 text-right">PEND SP</th>
              <th className="px-4 py-3">3M TREND</th>
              <th className="px-4 py-3">CONSTRAINT</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((it) => (
              <tr key={it.code} onClick={() => onSelectItem(it.code)} className="cursor-pointer border-b last:border-0 hover:bg-slate-50">
                <td className="px-4 py-3 font-semibold text-blue-600">{it.code}</td>
                <td className="px-4 py-3">{it.description}</td>
                <td className="px-4 py-3"><Badge variant="outline" className={it.type === "AMS1" ? "border-blue-200 text-blue-600" : "border-purple-200 text-purple-600"}>{it.type}</Badge></td>
                <td className="px-4 py-3 text-right">{it.ocq.toLocaleString()}</td>
                <td className="px-4 py-3 text-right">{it.ordQty.toLocaleString()}</td>
                <td className={`px-4 py-3 text-right font-semibold ${it.ordQty - it.ocq < 0 ? "text-amber-600" : "text-emerald-600"}`}>
                  {it.ordQty - it.ocq > 0 ? "+" : ""}{(it.ordQty - it.ocq).toLocaleString()}
                </td>
                <td className="px-4 py-3 text-right text-emerald-600">{it.autoSp ?? "—"}</td>
                <td className="px-4 py-3 text-right text-slate-400">{it.appvdSp ?? "—"}</td>
                <td className="px-4 py-3 text-right font-semibold text-red-500">{it.pendSp.toLocaleString()}</td>
                <td className="px-4 py-3"><Trend trend={it.trend} pct={it.trendPct} /></td>
                <td className="px-4 py-3">
                  {it.constrained ? (
                    <Badge className="border-red-200 bg-red-50 text-red-600" variant="outline">Constrained</Badge>
                  ) : (
                    <Badge className="border-emerald-200 bg-emerald-50 text-emerald-600" variant="outline">Clear</Badge>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
