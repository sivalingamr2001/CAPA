import { useState } from "react";
import { ChevronLeft, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Item, ItemDetailData, CatCode } from "../types";

interface ItemDetailProps {
  item: Item;
  detail: ItemDetailData;
  onBack: () => void;
}

const catColors: Record<CatCode, string> = {
  D1: "bg-emerald-100 text-emerald-700",
  D2: "bg-purple-100 text-purple-700",
  C2: "bg-blue-100 text-blue-700",
};

function Metric({ value, label, tone }: { value: string | number; label: string; tone?: string }) {
  return (
    <div className={`flex-1 rounded-lg border p-4 text-center ${tone ?? "bg-white"}`}>
      <div className="text-2xl font-bold">{value}</div>
      <div className="mt-1 text-[11px] font-semibold tracking-wide text-slate-400">{label}</div>
    </div>
  );
}

export default function ItemDetail({ item, detail, onBack }: ItemDetailProps) {
  const [selectAll, setSelectAll] = useState(false);
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [submitted, setSubmitted] = useState<Set<string>>(new Set());

  const toggleAll = (value: boolean) => {
    setSelectAll(value);
    setChecked(value ? new Set(detail.orders.map((o) => o.oaNo)) : new Set());
  };

  const toggleOne = (oaNo: string, value: boolean) => {
    const next = new Set(checked);
    value ? next.add(oaNo) : next.delete(oaNo);
    setChecked(next);
    setSelectAll(next.size === detail.orders.length);
  };

  const submitSp = (oaNo: string) => setSubmitted((prev) => new Set(prev).add(oaNo));
  const submitSelected = () => setSubmitted((prev) => new Set([...prev, ...checked]));

  return (
    <div className="mx-6 mb-6 rounded-xl border bg-white">
      <div className="flex items-center gap-2 border-b p-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-1 text-slate-500">
          <ChevronLeft className="h-4 w-4" /> Items
        </Button>
        <span className="text-slate-300">/</span>
        <span className="font-semibold text-blue-600">{item.code}</span>
        <span className="text-slate-500">{item.description}</span>
        <Badge variant="outline" className="border-blue-200 text-blue-600">{item.type}</Badge>
        {item.constrained && (
          <Badge variant="outline" className="gap-1 border-red-200 bg-red-50 text-red-600">
            <AlertTriangle className="h-3 w-3" /> Constraint — {item.constraintLabel}
          </Badge>
        )}
      </div>

      <div className="flex flex-wrap gap-3 p-4">
        <Metric value={detail.ocq} label="OCQ" />
        <Metric value={detail.totalOrders.toLocaleString()} label="TOTAL ORDERS" />
        <Metric value={`+${detail.abovePlan}`} label="ABOVE PLAN" tone="border-amber-200 bg-amber-50 text-amber-600" />
        <Metric value={detail.dispatched} label="DISPATCHED" tone="border-emerald-200 bg-emerald-50 text-emerald-600" />
        <Metric value={detail.autoSp} label="AUTO SP" tone="border-emerald-200 bg-emerald-50 text-emerald-600" />
        <Metric value={detail.appvdSp} label="APPVD SP" tone="text-slate-300" />
        <Metric value={detail.pendSpQty} label="PEND SP QTY" tone="border-amber-200 bg-amber-50 text-amber-600" />
      </div>

      <div className="mx-4 mb-4 rounded-lg border">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <span className="h-4 w-1 rounded bg-blue-500" />
            SALES ORDER BREAKUP
            <Badge variant="outline" className="border-blue-200 text-blue-600">{item.type} · Auto SP up to OCQ</Badge>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <label className="flex items-center gap-1.5">
              <Checkbox checked={selectAll} onCheckedChange={(v) => toggleAll(Boolean(v))} />
              Select All Pend SP
            </label>
            <Button size="sm" onClick={submitSelected} className="bg-blue-600 hover:bg-blue-700">
              Show All ({detail.orders.length})
            </Button>
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-left text-xs font-semibold text-slate-400">
              <th className="w-8 px-4 py-3" />
              <th className="px-4 py-3">CAT</th>
              <th className="px-4 py-3">CUSTOMER / DEALER</th>
              <th className="px-4 py-3">OA DATE</th>
              <th className="px-4 py-3">OA NO.</th>
              <th className="px-4 py-3 text-right">OA QTY</th>
              <th className="px-4 py-3 text-right">DISP</th>
              <th className="px-4 py-3 text-right">PEND ORD</th>
              <th className="px-4 py-3 text-right">AUTO SP</th>
              <th className="px-4 py-3">SUBMITTED</th>
              <th className="px-4 py-3 text-right">APPVD SP</th>
              <th className="px-4 py-3 text-right">PEND SP</th>
              <th className="px-4 py-3">TREND</th>
              <th className="px-4 py-3">ACTION</th>
            </tr>
          </thead>
          <tbody>
            {detail.orders.map((o) => (
              <tr key={o.oaNo} className="border-b last:border-0 hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Checkbox checked={checked.has(o.oaNo)} onCheckedChange={(v) => toggleOne(o.oaNo, Boolean(v))} />
                </td>
                <td className="px-4 py-3"><Badge className={`gap-1 ${catColors[o.cat]}`}>{o.cat}</Badge></td>
                <td className="px-4 py-3">{o.customer}</td>
                <td className="px-4 py-3 text-slate-500">{o.oaDate}</td>
                <td className="px-4 py-3 font-medium text-blue-600">{o.oaNo}</td>
                <td className="px-4 py-3 text-right">{o.oaQty}</td>
                <td className="px-4 py-3 text-right">{o.disp}</td>
                <td className="px-4 py-3 text-right text-amber-600">{o.pendOrd}</td>
                <td className="px-4 py-3 text-right text-emerald-600">{o.autoSp ?? "—"}</td>
                <td className="px-4 py-3 text-slate-300">—</td>
                <td className="px-4 py-3 text-right text-slate-300">—</td>
                <td className="px-4 py-3 text-right font-semibold text-red-500">{o.pendSp}</td>
                <td className="px-4 py-3"><Button variant="outline" size="sm">Trend</Button></td>
                <td className="px-4 py-3">
                  <Button
                    size="sm"
                    disabled={submitted.has(o.oaNo)}
                    onClick={() => submitSp(o.oaNo)}
                    className="bg-amber-100 text-amber-700 hover:bg-amber-200"
                  >
                    {submitted.has(o.oaNo) ? "Submitted" : "Submit SP"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
