import { Layers, Users, Clock, User, RefreshCw, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  activeTab: "items" | "customers";
  onTabChange: (tab: "items" | "customers") => void;
  onRefresh: () => void;
}

export default function Header({ activeTab, onTabChange, onRefresh }: HeaderProps) {
  return (
    <header className="flex items-center justify-between border-b bg-white px-6 py-3">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 text-white">
            <Zap className="h-5 w-5" fill="white" />
          </div>
          <div className="leading-tight">
            <div className="text-lg font-bold text-blue-700">JANATICS</div>
            <div className="text-[10px] tracking-widest text-slate-400">PES LITE</div>
          </div>
        </div>

        <nav className="flex items-center gap-2">
          <Button
            variant={activeTab === "items" ? "default" : "ghost"}
            size="sm"
            onClick={() => onTabChange("items")}
            className={activeTab === "items" ? "bg-blue-600 hover:bg-blue-700" : "text-slate-600"}
          >
            <Layers className="mr-1.5 h-4 w-4" />
            Items
          </Button>
          <Button
            variant={activeTab === "customers" ? "default" : "ghost"}
            size="sm"
            onClick={() => onTabChange("customers")}
            className={activeTab === "customers" ? "bg-blue-600 hover:bg-blue-700" : "text-slate-600"}
          >
            <Users className="mr-1.5 h-4 w-4" />
            Customers &amp; Dealers
          </Button>
        </nav>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs text-slate-500">
          <Clock className="h-3.5 w-3.5" />
          Thu, 16 Jul, 2026
        </div>
        <Button className="gap-1.5 bg-slate-900 hover:bg-slate-800">
          <User className="h-4 w-4" />
          Marketing Ops
        </Button>
        <Button variant="outline" size="icon" onClick={onRefresh} aria-label="Refresh dashboard">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}
