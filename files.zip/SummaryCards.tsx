import { Layers, BarChart2, ShieldAlert, TrendingUp, Edit3 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

interface SummaryCardsProps {
  constraintCodes: string[];
  onConstraintClick: (code: string) => void;
}

function ProgressBar({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function SummaryCards({ constraintCodes, onConstraintClick }: SummaryCardsProps) {
  return (
    <div className="grid grid-cols-1 gap-4 px-6 py-4 md:grid-cols-5">
      <Card className="border-t-4 border-t-blue-500 p-4">
        <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-slate-500">
          <Layers className="h-3.5 w-3.5" /> OA ITEMS VS CATALOG
        </div>
        <div className="space-y-2 text-xs">
          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="font-medium text-blue-600">AMS1</span>
              <span className="font-bold">14 / 590</span>
            </div>
            <ProgressBar pct={2} color="bg-blue-500" />
            <div className="mt-0.5 text-right text-slate-400">2% covered</div>
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="font-medium text-purple-600">AMS2</span>
              <span className="font-bold">8 / 245</span>
            </div>
            <ProgressBar pct={3} color="bg-purple-500" />
            <div className="mt-0.5 text-right text-slate-400">3% covered</div>
          </div>
        </div>
      </Card>

      <Card className="border-t-4 border-t-emerald-500 p-4">
        <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-slate-500">
          <BarChart2 className="h-3.5 w-3.5" /> OA QTY VS FULFILLED
        </div>
        <div className="text-2xl font-bold">13,546 <span className="text-sm font-normal text-slate-400">total</span></div>
        <div className="my-2 flex items-center justify-between text-xs">
          <span className="text-slate-500">Fulfilled: <b className="text-slate-700">10,544</b></span>
          <span className="font-semibold text-amber-600">78%</span>
        </div>
        <ProgressBar pct={78} color="bg-amber-400" />
      </Card>

      <Card className="border-t-4 border-t-red-500 p-4">
        <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-slate-500">
          <ShieldAlert className="h-3.5 w-3.5" /> CONSTRAINT ITEMS
        </div>
        <div className="text-2xl font-bold text-red-600">6 <span className="text-xs font-normal text-slate-400">of 22 items</span></div>
        <div className="mb-2 text-xs font-semibold text-red-500">27% blocked</div>
        <div className="flex flex-wrap gap-1">
          {constraintCodes.map((code) => (
            <Badge
              key={code}
              onClick={() => onConstraintClick(code)}
              className="cursor-pointer border-red-200 bg-red-50 text-red-600 hover:bg-red-100"
              variant="outline"
            >
              {code}
            </Badge>
          ))}
        </div>
      </Card>

      <Card className="border-t-4 border-t-orange-400 p-4">
        <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-slate-500">
          <TrendingUp className="h-3.5 w-3.5" /> AMS1 ABOVE OCQ
        </div>
        <div className="text-2xl font-bold text-orange-500">7 <span className="text-xs font-normal text-slate-400">of 14 AMS1 items</span></div>
        <div className="mb-2 text-xs font-semibold text-orange-500">exceed OCQ plan</div>
        <ProgressBar pct={50} color="bg-orange-400" />
      </Card>

      <Card className="border-t-4 border-t-purple-500 p-4">
        <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-slate-500">
          <Edit3 className="h-3.5 w-3.5" /> SP PENDING
        </div>
        <div className="text-2xl font-bold text-purple-600">7,151</div>
        <div className="mb-2 text-xs text-slate-400">units awaiting sales plan</div>
        <Badge variant="outline" className="border-purple-200 bg-purple-50 text-purple-600">
          15 items
        </Badge>
      </Card>
    </div>
  );
}
