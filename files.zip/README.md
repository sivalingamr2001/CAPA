# Janatics PES Lite — Dashboard Components

React + TypeScript components built with shadcn/ui + Tailwind, matching the
provided screenshots pixel-for-pixel in structure (top nav, 5 KPI cards,
items table, item detail view, bottom status bar).

## Files
- `types.ts` — shared TypeScript interfaces
- `mock-data.ts` — sample items + PV-5001 sales order breakup (add more entries to `itemDetails` for other item codes)
- `components/Header.tsx` — top nav (logo, Items/Customers tabs, date, profile, refresh)
- `components/SummaryCards.tsx` — the 5 KPI cards (persist on both pages)
- `components/ItemsTable.tsx` — items list: search, TYPE/CONSTRAINT filters, SP Pending toggle, clickable rows
- `components/ItemDetail.tsx` — item detail: breadcrumb, 7 metric tiles, sales order breakup table with checkboxes + Submit SP
- `components/Footer.tsx` — bottom status bar
- `components/Dashboard.tsx` — orchestrator; holds nav state, renders Header + SummaryCards (always) + ItemsTable OR ItemDetail

## Behavior
- Clicking any item row (or a constraint-chip badge on the KPI cards) opens that item's detail page.
- The top summary cards and header never unmount — only the main body swaps between the items table and the item detail view, exactly like the two screenshots.
- Constraint chips, Submit SP buttons, Select All, and the Show All button are all wired to local state.

## Setup (in an existing Next.js/Vite + Tailwind project)
```bash
npx shadcn@latest add button input badge checkbox card
npm install lucide-react
```
Then drop these files into your project (e.g. `src/dashboard/`) and render:
```tsx
import Dashboard from "./dashboard/components/Dashboard";
export default function Page() {
  return <Dashboard />;
}
```
