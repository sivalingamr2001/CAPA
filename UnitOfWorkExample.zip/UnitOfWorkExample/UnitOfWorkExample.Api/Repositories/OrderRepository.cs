using Dapper;
using UnitOfWorkExample.Api.Database.Abstractions;
using UnitOfWorkExample.Api.Domain.Orders;
using UnitOfWorkExample.Api.Repositories.Abstractions;

namespace UnitOfWorkExample.Api.Repositories;

public sealed class OrderRepository(IUnitOfWork unitOfWork) : IOrderRepository
{
    public Task AddAsync(Order order)
        => unitOfWork.Connection.ExecuteAsync(
            """
            INSERT INTO "Orders" ("Id", "ProductId", "Quantity")
            VALUES (@Id, @ProductId, @Quantity)
            """,
            order,
            unitOfWork.Transaction);
}

