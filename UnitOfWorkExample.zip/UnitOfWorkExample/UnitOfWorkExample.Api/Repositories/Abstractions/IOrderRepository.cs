using UnitOfWorkExample.Api.Domain.Orders;

namespace UnitOfWorkExample.Api.Repositories.Abstractions;

public interface IOrderRepository
{
    Task AddAsync(Order order);
}

