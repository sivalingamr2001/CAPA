namespace UnitOfWorkExample.Api.Repositories.Abstractions;

public interface IProductRepository
{
    Task ReduceStockAsync(Guid productId, int quantity);
}

