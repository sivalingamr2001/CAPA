using Dapper;
using UnitOfWorkExample.Api.Database.Abstractions;
using UnitOfWorkExample.Api.Repositories.Abstractions;

namespace UnitOfWorkExample.Api.Repositories;

public sealed class ProductRepository(IUnitOfWork unitOfWork) : IProductRepository
{
    public Task ReduceStockAsync(Guid productId, int quantity)
        => unitOfWork.Connection.ExecuteAsync(
            """
            UPDATE "Products"
            SET "Stock" = "Stock" - @Quantity
            WHERE "Id" = @ProductId
            """,
            new { ProductId = productId, Quantity = quantity },
            unitOfWork.Transaction);
}

