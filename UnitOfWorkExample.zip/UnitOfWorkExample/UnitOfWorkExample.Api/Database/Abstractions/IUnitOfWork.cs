using System.Data;

namespace UnitOfWorkExample.Api.Database.Abstractions;

public interface IUnitOfWork : IAsyncDisposable
{
    IDbConnection Connection { get; }
    IDbTransaction? Transaction { get; }

    Task BeginAsync();
    Task CommitAsync();
    Task RollbackAsync();
}

