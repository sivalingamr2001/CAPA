CREATE TABLE "Products" (
    "Id" UUID PRIMARY KEY,
    "Name" TEXT NOT NULL,
    "Stock" INTEGER NOT NULL
);

CREATE TABLE "Orders" (
    "Id" UUID PRIMARY KEY,
    "ProductId" UUID NOT NULL REFERENCES "Products" ("Id"),
    "Quantity" INTEGER NOT NULL
);

INSERT INTO "Products" ("Id", "Name", "Stock")
VALUES ('11111111-1111-1111-1111-111111111111', 'Sample Product', 100);
