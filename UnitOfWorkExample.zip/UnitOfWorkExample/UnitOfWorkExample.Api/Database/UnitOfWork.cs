using System.Data;
using System.Data.Common;
using UnitOfWorkExample.Api.Database.Abstractions;
using Npgsql;

namespace UnitOfWorkExample.Api.Database;

public sealed class UnitOfWork(string connectionString) : IUnitOfWork
{
    private readonly DbConnection _connection = new NpgsqlConnection(connectionString);
    private DbTransaction? _transaction;

    public IDbConnection Connection => _connection;
    public IDbTransaction? Transaction => _transaction;

    public async Task BeginAsync()
    {
        if (_transaction is not null)
            throw new InvalidOperationException("Transaction already started.");

        if (_connection.State != ConnectionState.Open)
            await _connection.OpenAsync();

        _transaction = await _connection.BeginTransactionAsync();
    }

    public async Task CommitAsync()
    {
        if (_transaction is null)
            throw new InvalidOperationException("Transaction was not started.");

        await _transaction.CommitAsync();
        await _transaction.DisposeAsync();
        _transaction = null;
    }

    public async Task RollbackAsync()
    {
        if (_transaction is null)
            return;

        await _transaction.RollbackAsync();
        await _transaction.DisposeAsync();
        _transaction = null;
    }

    public async ValueTask DisposeAsync()
    {
        if (_transaction is not null)
            await _transaction.DisposeAsync();

        await _connection.DisposeAsync();
    }
}

