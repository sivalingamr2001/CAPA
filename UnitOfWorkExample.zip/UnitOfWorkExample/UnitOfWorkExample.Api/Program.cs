using UnitOfWorkExample.Api.Database;
using UnitOfWorkExample.Api.Database.Abstractions;
using UnitOfWorkExample.Api.Domain.Orders;
using UnitOfWorkExample.Api.Repositories;
using UnitOfWorkExample.Api.Repositories.Abstractions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var connectionString = builder.Configuration.GetConnectionString("Postgres")!;

builder.Services.AddScoped<IUnitOfWork>(_ =>
    new UnitOfWork(connectionString));

builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IOrderRepository, OrderRepository>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapPost("orders/", async (
    PlaceOrderRequest request,
    IUnitOfWork unitOfWork,
    IProductRepository products,
    IOrderRepository orders) =>
{
    await unitOfWork.BeginAsync();

    try
    {
        await products.ReduceStockAsync(request.ProductId, request.Quantity);

        var order = new Order(request.ProductId, request.Quantity);
        await orders.AddAsync(order);

        await unitOfWork.CommitAsync();

        return Results.Ok(order.Id);
    }
    catch
    {
        await unitOfWork.RollbackAsync();
        throw;
    }
});

app.Run();

public sealed record PlaceOrderRequest(Guid ProductId, int Quantity);

